import React from 'react';

const person=(props)=>{
console.log(props);
    return (

       <div>
 <li onClick={props.click}>
                {props.name}
            </li>
       </div>
           
  
    )
}

export default person;