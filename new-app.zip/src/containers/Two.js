import React ,{Component}from 'react';
import Header from '../components/header/header';
import {connect} from 'react-redux';

class Two extends Component{

   
    render(){
        console.log(this.props)
        return(

            <React.Fragment>

            <Header />
            <h4>I AM Two {this.props.counter}</h4>
        </React.Fragment>
        )
    }
}

const mapStateToProps=state=>{

    return {
        ...state
    }
}
export default connect(mapStateToProps)(Two);