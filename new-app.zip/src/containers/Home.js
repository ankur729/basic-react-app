import React ,{Component}from 'react';
import Header from '../components/header/header';
class Home extends Component{

    render(){

        return(
            <React.Fragment>
   <Header />
            <h1>I AM HOME </h1>
            </React.Fragment>
         
        )
    }
}

export default Home;