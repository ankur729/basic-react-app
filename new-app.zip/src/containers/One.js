import React ,{Component}from 'react';
import Header from '../components/header/header';
import {Helmet} from "react-helmet";
import {connect} from 'react-redux';
import * as actiontypes from '../constants/actiontypes';

class One extends Component{

    authenticateHandler=()=>{

        
    }
    render(){
console.log(this.props);
        return(

            <React.Fragment>
 <Helmet>
                <meta charSet="utf-8" />
                <title>My Title</title>
                <link rel="canonical" href="http://mysite.com/example" />
            </Helmet>   
                <Header />
                <h4>I AM ONE {this.props.counter} </h4>

                <button onClick={this.props.onIncrementCounter}>Authenticate Now</button>
            </React.Fragment>
            
        )
    }
}

const mapStateToProps=state=>{
return{
   ...state,
    
}
}

const mapDispatchToProps=dispatch=>{
    return {
        onIncrementCounter:()=>dispatch(actiontypes.incrementCounter())
    }
}
export default connect(mapStateToProps,mapDispatchToProps)(One);