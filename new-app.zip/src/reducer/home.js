import { HOME_PAGE_LOADED,INCREMENT_COUNTER, HOME_PAGE_UNLOADED } from '../constants/actiontypes';

export default (state = {'counter':0    }, action) => {
  switch (action.type) {
    case HOME_PAGE_LOADED:
      return {
        ...state,
        tags: action.payload[0].tags
      };
      case INCREMENT_COUNTER:alert(2)
      // return {
      //   ...state.home,
      //   counter:state.counter+1
      // };

      
    case HOME_PAGE_UNLOADED:
      return {};
    default:
      return state;
  }
};