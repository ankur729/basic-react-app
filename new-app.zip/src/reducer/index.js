import home  from './home';
import settings  from './settings';

import {combineReducers} from 'redux';

const rootReducer =  (state={counter:0},action)=>{

  if(action.type=='INCREMENT'){
    console.log(state.counter);
    return {

      counter:state.counter+1
    }
  }
}
// const rootReducer = combineReducers({
//     home: home,
//     settings: settings,
//   });
export default rootReducer;
