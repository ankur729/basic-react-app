import {
    SETTINGS_SAVED,
    SETTINGS_PAGE_UNLOADED,
    ASYNC_START
} from '../constants/actiontypes';

export default (state = {'counter':0    }, action) => {

    switch (action.type) {

        case SETTINGS_SAVED:
            return {
                ...state,
                inProgress: false,

            };
        case ASYNC_START:
            return {
                ...state,
                inProgress: true
            };
        default:
            return state;
    }
}
  