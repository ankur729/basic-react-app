import React ,{Component} from 'react';
import logo from './logo.svg';
import './App.css';
import Person from './Person/Person';
import {BrowserRouter} from 'react-router-dom';
import AppRoute from './AppRoute';
import { Provider } from 'react-redux';
import store from './store';

class App extends Component {

/** Shalow copy  

var oldObject = {
  name: 'A',
  address: {
    street: 'Station Road',
    city: 'Pune'
  }
}
var newObject = JSON.parse(JSON.stringify(oldObject));
/** */
state={
  persons:[{'name':'aa','age':'28'},{'name':'bc','age':'23'}],
  showPersons:false
}

calledFromChild=(val)=>{

  console.log('This is called from child--'+val);
  const doesshow=this.state.showPersons;
  this.setState({showPersons:!doesshow});
}

deletePersonHandler = (person) => {
  const persons = this.state.persons;

  const idx=persons.findIndex(elem=>elem.name==person)
  persons.splice(idx,1);
  this.setState({persons});
  console.log(idx);
  // const persons = [...this.state.persons];
  // persons.splice(personIndex, 1);
  // this.setState({persons: persons});
}

render(){

  // let persons=null;
  // if(this.state.showPersons){
  //   persons=( 
      
  //     <div>
  //       <ul  > 
  //       {this.state.persons.map((person,index)=>{
  //       return  <Person name={person.name} 
  //       click={()=> this.deletePersonHandler(person.name)}
  //       key={person.age}
  //      />
  //       })}
  //       </ul>
  //     </div>
  //     );
      
  // }  


  return (
    <Provider store={store}>
     <AppRoute />
     </Provider>
  );
}
 
}

export default App;
