import React , {Component,Suspense}from 'react';
import {Router,Route,Switch} from 'react-router-dom';
import createHistory from 'history/createBrowserHistory';
import Home from './containers/Home';
const One =React.lazy(()=> 
    import('./containers/One')
 );
const Two =React.lazy(()=> 
    import('./containers/Two')
 );

// import One from './containers/One';
// import Two from './containers/Two';


class AppRoute extends Component{

    render(){

        const history = createHistory();
        return (
            <Router history={history}>
            <Route path="/"  exact component={Home}/>
            <Switch>
            <Route path="/home" component={Home}/>
                <Route path="/one" render={()=><Suspense fallback={<div>loading..</div>}><One/></Suspense>}  />
                <Route path="/two" render={()=><Suspense fallback={<div>loading..</div>}><Two/></Suspense>} />
                </Switch>
            </Router>
        );
    }
}

export default AppRoute;