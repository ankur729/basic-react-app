import React from 'react';

const authContext= React.createContext({
    state:{
        authenticated:false
    }
})

export default authContext;