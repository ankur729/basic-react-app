import React   from 'react';
import   './header.css';
import {NavLink} from 'react-router-dom';
import store from '../../store';
import {connect} from 'react-redux';

const header=(props)=>{

  function  incrementCounterHandler(){

        console.log('Increment counter handler loads');

         fetch('https://jsonplaceholder.typicode.com/posts/').then(res=>{
            res.json().then(ress=>{
                let arr=Array.from(new Set(ress.slice(0,10).map(JSON.stringify))).map(JSON.parse) ;
                let newarr='123';
                console.log(Array.from(newarr,x=>x+x))
                 
                console.log(arr)
            })
            
         })
      //  store.dispatch({ type: SETTINGS_SAVED, payload: 0 })
    }
 
   console.log('header renders..'+props);
    return (

        <React.Fragment>
            <ul className="header">
            <NavLink to="/home"> <li>Home</li></NavLink>
            <NavLink to="/one">  <li>One</li></NavLink>
            <NavLink to="/two">    <li>Two {props.counter}</li></NavLink>

            <button onClick={incrementCounterHandler}>Increment Counter</button>
            </ul>
        </React.Fragment>
    )
}
 
const mapStateToProps=state=>{
    return {
        ...state,
    }
}
export default connect(mapStateToProps)(header);